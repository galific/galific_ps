<?php

if (!defined('_PS_VERSION_'))
	exit;

function upgrade_module_1_3_4($module)
{
	return true;
}
