<?php
$sql = array();
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'pos_staticfooter`';
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'pos_staticfooter_lang`';
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'pos_staticfooter_shop`';

