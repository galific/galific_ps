**Maintainer's Wanted!** - Ineterested in contributing regularly to Nivo Lightbox development? [Get in touch](https://dev7studios.com/support/contact/)

Nivo Lightbox
=============

A simple, flexible, responsive, retina-ready jQuery lightbox plugin. See http://dev7studios.com/nivo-lightbox for more info.

Docs: http://docs.dev7studios.com/category/10-nivo-lightbox
